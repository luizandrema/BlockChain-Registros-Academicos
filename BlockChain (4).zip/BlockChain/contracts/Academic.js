const web3 = new Web3("http://127.0.0.1:8545");

const contractAddress = "0x28C7d5719ea654f5eBf6599fcd7Ab2747A112666"; 
const contractABI = [
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_estudante",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "_estudante_id",
                "type": "uint256"
            },
            {
                "internalType": "string",
                "name": "_nome",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "_grau",
                "type": "string"
            }
        ],
        "name": "adicionarRegistro",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "_estudante",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "_estudante_id",
                "type": "uint256"
            }
        ],
        "name": "getRegistro",
        "outputs": [
            {
                "internalType": "string",
                "name": "nome",
                "type": "string"
            },
            {
                "internalType": "string",
                "name": "grau",
                "type": "string"
            },
            {
                "internalType": "bool",
                "name": "valido",
                "type": "bool"
            },
            {
                "internalType": "uint256",
                "name": "timestamp",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    }
];

const academicContract = new web3.eth.Contract(contractABI, contractAddress);

async function adicionarRegistro() {
    const studentAddress = document.getElementById('studentAddress').value;
    const studentID = document.getElementById('studentID').value;
    const name = document.getElementById('name').value;
    const degree = document.getElementById('degree').value;

    if (!web3.utils.isAddress(studentAddress)) {
        document.getElementById('saida').innerText = 'Endereço do estudante inválido.';
        return;
    }

    if (!name || !degree || !studentID) {
        document.getElementById('saida').innerText = 'Por favor, preencha todos os campos.';
        return;
    }

    try {
        const accounts = await web3.eth.getAccounts();
        const account = accounts[0];

        await academicContract.methods.adicionarRegistro(studentAddress, studentID, name, degree).send({ from: account });

        document.getElementById('saida').innerText = 'Registro adicionado com sucesso!';
    } catch (error) {
        document.getElementById('saida').innerText = `Erro: ${error.message}`;
    }
}

async function verRegistro() {
    const studentAddress = document.getElementById('studentAddress').value;
    const studentID = document.getElementById('studentID').value;

    if (!web3.utils.isAddress(studentAddress)) {
        document.getElementById('saida').innerText = 'Endereço do estudante inválido.';
        return;
    }

    if (!studentID) {
        document.getElementById('saida').innerText = 'Por favor, preencha todos os campos.';
        return;
    }

    try {
        const registro = await academicContract.methods.getRegistro(studentAddress, studentID).call();
        if (registro.timestamp !== "0") {
            const registrosDiv = document.getElementById('registros');
            registrosDiv.innerHTML = `
                <h2>Registro Acadêmico</h2>
                <p><strong>ID do Estudante:</strong> ${studentID}</p>
                <p><strong>Nome:</strong> ${registro.nome}</p>
                <p><strong>Grau:</strong> ${registro.grau}</p>
                <p><strong>Valido:</strong> ${registro.valido ? 'Sim' : 'Não'}</p>
                <p><strong>Timestamp:</strong> ${new Date(registro.timestamp * 1000)}</p>
            `;
        } else {
            document.getElementById('saida').innerText = 'Registro não encontrado.';
        }
    } catch (error) {
        document.getElementById('saida').innerText = `Erro: ${error.message}`;
    }
}

window.addEventListener('load', async () => {
    const accounts = await web3.eth.getAccounts();
    web3.eth.defaultAccount = accounts[0];
});
